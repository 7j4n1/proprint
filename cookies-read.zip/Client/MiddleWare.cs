using Microsoft.AspNetCore.Http;

namespace Client
{

    public class Middleware {

    private static readonly HttpClient _httpClient = new HttpClient();

    public async Task Invoke(HttpContext _httpContext)
    {
      // _logger.LogInformation("Middleware executing...");
      var targetUri = BuildTargetUri(_httpContext.Request.Path);

      if (targetUri != null) {
        var targetRequestMessage = CreateTargetMessage(_httpContext, targetUri);

        using(var responseMessage = await _httpClient.SendAsync(targetRequestMessage, HttpCompletionOption.ResponseHeadersRead, _httpContext.RequestAborted))
        {
          _httpContext.Response.StatusCode  = (int)responseMessage.StatusCode;
          CopyFromTargetResponseHeaders(_httpContext, responseMessage);
          await responseMessage.Content.CopyToAsync(_httpContext.Response.Body);
        }
        return;
      }
    //   await _next(_httpContext);
    }

    private HttpRequestMessage CreateTargetMessage(HttpContext _httpContext, Uri targetUri)
    {
      var requestMessage = new HttpRequestMessage();
      CopyFromOriginalRequestContentAndHeaders(_httpContext, requestMessage);

      requestMessage.RequestUri = targetUri;
      requestMessage.Headers.Host = targetUri.Host;
      requestMessage.Method = GetMethod(_httpContext.Request.Method);

      return requestMessage;
    }

    private void CopyFromOriginalRequestContentAndHeaders(HttpContext _httpContext, HttpRequestMessage requestMessage)
    {
      var requestMethod = _httpContext.Request.Method;

      if (!HttpMethods.IsGet(requestMethod) &&
      !HttpMethods.IsHead(requestMethod) &&
      !HttpMethods.IsDelete(requestMethod) &&
      !HttpMethods.IsTrace(requestMethod))
      {
        var _streamContent = new StreamContent(_httpContext.Request.Body);
        requestMessage.Content = _streamContent;
      }

      foreach (var header in _httpContext.Request.Headers)
      {
        requestMessage.Content?.Headers.TryAddWithoutValidation(header.Key, header.Value.ToArray());
      }
    }

    private void CopyFromTargetResponseHeaders(HttpContext _httpContext, HttpResponseMessage responseMessage)
    {
      foreach (var header in responseMessage.Headers) {
        _httpContext.Response.Headers[header.Key] = header.Value.ToArray();
      }

      foreach (var header in responseMessage.Content.Headers) {
        _httpContext.Response.Headers[header.Key] = header.Value.ToArray();
      }
      _httpContext.Response.Headers.Remove("transfer-encoding");
    }

    private static HttpMethod GetMethod(string method)
    {
      if (HttpMethods.IsDelete(method)) return HttpMethod.Delete;
      if (HttpMethods.IsGet(method)) return HttpMethod.Get;
      if (HttpMethods.IsHead(method)) return HttpMethod.Head;
      if (HttpMethods.IsOptions(method)) return HttpMethod.Options;
      if (HttpMethods.IsPost(method)) return HttpMethod.Post;
      if (HttpMethods.IsPut(method)) return HttpMethod.Put;
      if (HttpMethods.IsTrace(method)) return HttpMethod.Trace;
      return new HttpMethod(method);
    }

    private Uri BuildTargetUri(string url)
    {
      Uri? targetUri = null;

      
      targetUri = new Uri(url);

      return targetUri;
    }
  }
}
