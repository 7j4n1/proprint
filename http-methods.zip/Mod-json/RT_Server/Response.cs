using System;

namespace RT_Server
{
    public class Response
    {
        public string? cliID {get; set;}

        public string? method {get; set;}

        public string? response {get; set;}

        public string? headers {get; set;}

        public string? contentType {get; set;}

        public string? request {get; set;}

        public string? protocol {get; set;}
    }
}