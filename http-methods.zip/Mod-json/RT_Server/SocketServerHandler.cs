using System.Collections.Concurrent;
using System.Collections.Specialized;
using System.Net;
using System.Net.WebSockets;
using System.Text;
using System.Web;

namespace RT_Server
{
    public class SocketServerHandler {

        public WebSocketHandler _socketHandler  = new WebSocketHandler();
        public ConcurrentDictionary<string, Stream> storage = new ConcurrentDictionary<string, Stream>();
        public ConcurrentDictionary<string, HttpListenerContext> _httpReqLists = new ConcurrentDictionary<string,HttpListenerContext>();
        private static UTF8Encoding encoding = new UTF8Encoding();

        public async void Run(string _httpListener_prefix)
        {
            HttpListener _listener = new HttpListener();
            _listener.Prefixes.Add(_httpListener_prefix);
            _listener.Start();

            Console.WriteLine($"Listening on {_httpListener_prefix}");

            while(true)
            {
                var _context = await _listener.GetContextAsync();
                // create a new Request Connection id
                var _reqId = _socketHandler.CreateConnectionId();

                // save id and context
                _httpReqLists.TryAdd(_reqId, _context);

                if(_context.Request.IsWebSocketRequest)
                {
                    // Handle Web Socket Request Here
                    HandleSocketRequest(_context);
                }else {
                    
                    // This is a http request handler from browser
                    _context.Response.StatusCode = 200;
                    // _context.Response.OutputStream.Write(strA, 0, strA.Length);
                    // _context.Response.OutputStream.Flush();
                    
                    // var writer = new StreamWriter(_context.Response.OutputStream);
                    
                    //   Console.WriteLine(_context.Request.Headers);
                    // get the client id from uri
                    var urln = _context.Request.RawUrl;
                    // Console.WriteLine($"HTTP Request: {urln}");
                    var getCliID = urln.Split("/")[1];
                    // Console.WriteLine(getCliID);
                    // check if client ID exists
                    var cliSocket = _socketHandler._getSocket(getCliID);
                    if(cliSocket != null)
                    {
                        // Console.WriteLine(cliSocket);
                        try {
                                Console.WriteLine("Request Headers\r\n");
                                Console.WriteLine($"{_context.Request.HttpMethod} {urln} HTTP/{_context.Request.ProtocolVersion}\r\n");
                                Console.WriteLine(_context.Request.Headers.ToString());
                                
                                
                                string content = "";
                                Dictionary<string, string> headersAll = new Dictionary<string, string>();
                                
                                if (_context.Request.HasEntityBody)
                                {
                                    // for POST Method Request
                                    Console.WriteLine($"Length: {_context.Request.ContentLength64}, Content-Type: {_context.Request.ContentType}");
                                    StreamReader streamReader = new StreamReader(_context.Request.InputStream);
                                    content = streamReader.ReadToEnd();
                                    Console.WriteLine(content);
                                }
                                // Set all headers and values into dictionary
                                var obj = new Response
                                {
                                    cliID = _reqId,
                                    method = _context.Request.HttpMethod,
                                    response = content,
                                    headers = ConstructQueryString(_context.Request.Headers),
                                    request = urln,
                                    contentType = _context.Request.ContentType,
                                    protocol = _context.Request.ProtocolVersion.ToString()
                                };
                                var jsonReq = Newtonsoft.Json.JsonConvert.SerializeObject(obj);

                                byte[] bRequest = encoding.GetBytes(jsonReq);
                                
                                await cliSocket.SendAsync(new ArraySegment<byte>(bRequest), WebSocketMessageType.Binary, true, CancellationToken.None);

                                
                        } catch (Exception ex) {
                            Console.WriteLine($"HttpRequest Error: {ex.HResult}");
                        }
                    }

                }
            }
        }

        // Handle WebSocket Request
        private async void HandleSocketRequest(HttpListenerContext _httpContext)
        {
            WebSocketContext? _webSocketCxt = null;

            try
            {
                _webSocketCxt = await _httpContext.AcceptWebSocketAsync(null);
                string ip = _httpContext.Request.RemoteEndPoint.Address.ToString();
                Console.WriteLine($"Connected: {ip}");

            } catch (Exception ex) {
                _httpContext.Response.StatusCode = 500;
                _httpContext.Response.Close();
                Console.WriteLine($"Request Handling failed: {ex}");
                return;
            }

            WebSocket _socket = _webSocketCxt.WebSocket;
            // OnConnected(_socket);
            byte[] buf = new byte[1024];
            await _socket.ReceiveAsync(new ArraySegment<byte>(buf), CancellationToken.None);
            var getCli = Encoding.UTF8.GetString(buf).TrimEnd('\0');
            _socketHandler.OnConnected(_socket, getCli);
            Console.WriteLine($"ClientID: {_socketHandler._getID(_socket)}");

            try {

                while (_socket.State == WebSocketState.Open)
                {
                    var rcvBuffer = new ArraySegment<byte>(new byte[8192]);
                    var totalBytes = new List<byte>();
                    WebSocketReceiveResult? data = null;

                    do {
                        data = await _socket.ReceiveAsync(rcvBuffer, CancellationToken.None);
                        for (int i=0; i < data.Count; i++)
                        {
                            totalBytes.Add(rcvBuffer.Array[i]);
                        }
                    } while(!data.EndOfMessage);
                    
                    
                    // Console.WriteLine($"Recv Type: {data.MessageType}");
                    // Console.WriteLine($"Length: {totalBytes.Count}");
                    var recvData = Encoding.UTF8.GetString(totalBytes.ToArray(), 0, totalBytes.Count).TrimEnd('\0');

                    // Console.WriteLine($"Data: {recvData}");
                    if(recvData.Contains("SET ")){

                        var reply = _socketHandler._setID(_socket, recvData.Split(" ")[1]);
                        Console.WriteLine($"Set ID: {reply}");
                        Console.WriteLine("<==========End of Reply==========>");
                    }else {
                        var DeRep = Newtonsoft.Json.JsonConvert.DeserializeObject<Response>(recvData);
                        
                        Console.WriteLine($"Response Headers: \r\n");
                        Console.WriteLine($"{DeRep.headers}");

                        HttpListenerContext _resContext;
                        _httpReqLists.TryGetValue(DeRep.cliID, out _resContext);
                        
                        Console.WriteLine($"Content-Type: {DeRep.contentType}");
                        _resContext.Response.ContentType = DeRep.contentType;
                        var respBytes = Convert.FromBase64String(DeRep.response);
                        // Console.WriteLine(_resContext.Response..ToString());
                        _resContext.Response.OutputStream.Write(respBytes, 0, respBytes.Length);
                        _resContext.Response.OutputStream.Flush();

                        _resContext.Response.OutputStream.Close();
                        // using (var writer = new StreamWriter(_resContext.Response.OutputStream.Write())){
                        //     await writer.WriteLineAsync(Base64Dec(DeRep.response));
                        //     // await writer.WriteLineAsync(recvData);
                        //     await writer.Write()
                        //     writer.Flush();
                        // }
                        
                        // writer.Close();
                    }

                    if(data.MessageType == WebSocketMessageType.Close)
                     {   
                        Console.WriteLine("Error occured");
                        await _socket.CloseAsync(WebSocketCloseStatus.NormalClosure, "", CancellationToken.None);
                   } 
                //    else {
                    //    Console.WriteLine("Hello Here");
                        // await _socket.SendAsync(new ArraySegment<byte>(rcvBuffer, 0,
      //data.Count), messageType: WebSocketMessageType.Binary,
      //endOfMessage: data.EndOfMessage,
      //cancellationToken: CancellationToken.None);
                    // }
                }
            } catch (Exception ex) {
                // Console.WriteLine($"Error: {ex}");

                await _socketHandler.OnDisconnected(_socket);
                Console.WriteLine("A client got disconnected...");
            } finally {
                if(_socket != null)
                    _socket.Dispose();
            }
        }

        public static string Base64Dec(string encoded)
        {
            var byteStr = Convert.FromBase64String(encoded);
            return encoding.GetString(byteStr);
        }

        public static string ConstructQueryString(NameValueCollection parameters)
        {
            List<string> items = new List<string>();

            foreach (string name in parameters)
                items.Add(string.Concat(name, "=", HttpUtility.UrlEncode(parameters[name])));

            return string.Join("&", items.ToArray());
        }
    }
}
