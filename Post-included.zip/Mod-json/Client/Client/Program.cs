﻿using System.Collections.Generic;
using System.Collections.Concurrent;
using System;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Net.WebSockets;
using System.Threading;
using System.Threading.Tasks;
using System.Text.RegularExpressions;
using Newtonsoft.Json;
using System.Web;
using System.Collections.Specialized;

namespace Client {

    public class Program {

        private static UTF8Encoding encoding = new UTF8Encoding();
        

        static void Main(string[] args)
        {
            var config = GetConfigData();
            var host = config.FirstOrDefault(p => p.Key == "host").Value;
            var port = config.FirstOrDefault(p => p.Key == "port").Value;
            var id = config.FirstOrDefault(p => p.Key == "clientID").Value;

            Connect($"ws://{host}:{port}/", id).Wait();
            Console.WriteLine("Press any key to exit...");
            Console.ReadKey();
        }

        public static async Task Connect(string url, string id)
        {
            // Thread.Sleep(1000);

            ClientWebSocket client = null;
            try {
                client = new ClientWebSocket();
                await client.ConnectAsync(new Uri(url), CancellationToken.None);

                byte[] buffer = encoding.GetBytes(id);
                await client.SendAsync(new ArraySegment<byte>(buffer), WebSocketMessageType.Binary, false, CancellationToken.None);

                // await Task.WhenAll(Receive(client), Send(client));
                await Receive(client);
            } catch (Exception ex){
                Console.WriteLine($"Exception: {ex.HResult}");
            }finally
            {
                if(client != null)
                    client.Dispose();

                Console.WriteLine();
                Console.WriteLine("websocket closed.");
            }
        }

        private static async Task Send(ClientWebSocket socket)
        {
            while(socket.State == WebSocketState.Open)
            {
                Console.WriteLine("Send Command: ");
                string? stringToSend = Console.ReadLine();
                var buffer = encoding.GetBytes(stringToSend);

                await socket.SendAsync(new ArraySegment<byte>(buffer), WebSocketMessageType.Binary, true, CancellationToken.None);
                Console.WriteLine($"Sent: {stringToSend}");
                

                await Task.Delay(1000);
            }
        }

        private static async Task Receive(ClientWebSocket socket)
        {
            
            while(socket.State == WebSocketState.Open)
            {
                byte[] buffer = new byte[4096*10];
                // Console.Clear();
                var result = await socket.ReceiveAsync(new ArraySegment<byte>(buffer), CancellationToken.None);
                
                // Console.WriteLine(result.MessageType);

                if(result.MessageType == WebSocketMessageType.Close)
                {
                    Console.WriteLine("Socket Closed");
                    await socket.CloseAsync(WebSocketCloseStatus.NormalClosure, string.Empty, CancellationToken.None);
                } else {
                  // check the buffer object type
                  var response = Encoding.UTF8.GetString(buffer).Trim();
                //   Console.WriteLine($"Received: ({response})");
                    // DeserializeObject response
                  var DeRep =  JsonConvert.DeserializeObject<Response>(response);
                //   Console.WriteLine($"{DeRep.method}\n{DeRep.request}\n{DeRep.cliID}");
                // Console.WriteLine(DeRep);
                var webHeaderCollection = DeRep.headers;
                var parsedHeaders = parseQuery(DeRep.headers);
                  if (DeRep.method != "" || webHeaderCollection.Contains("Connection: "))
                  {
                    // parse the method and url from the  httpRequest response string
                    var method = DeRep.method;
                    var url = DeRep.request.Substring(DeRep.request.IndexOf("=")+1);
                    // var url = DeRep.request.Split("=")[1];
                    var connID = DeRep.cliID; 
                    // Console.WriteLine($"{method}\n{url}\n{connID}");
                    Console.WriteLine("Request: Header\r\n");
                    // Console.WriteLine($"{method} {url}\r\n{DecodeQueryString(parsedHeaders)}");
                    Console.WriteLine($"{method} {url} HTTP/{DeRep.protocol}\r\n");
                    foreach(string key in parsedHeaders)
                        Console.WriteLine($"{key}: {parsedHeaders[key]}");
                    // parse the response headers from the string
                    // var parsed = GetHeaders(response);

                    HttpClient _httpCl = new HttpClient();
                    var requestMessage = new HttpRequestMessage();
                    if (method == "GET")
                    {
                        requestMessage.Method = HttpMethod.Get;
                    }else if (method == "HEAD")
                    {
                        requestMessage.Method = HttpMethod.Head;
                    } else if (method == "POST")
                    {
                        Console.WriteLine("POST called");

                        requestMessage.Method = HttpMethod.Post;

                        if(string.IsNullOrEmpty(DeRep.response) == false)
                            requestMessage.Content = new StringContent(DeRep.response, Encoding.UTF8, DeRep.contentType);
                    }
                    try
                    {
                        requestMessage.Headers.Accept.TryParseAdd(parsedHeaders["Accept"]);
                        
                        // bool isAccept = requestMessage.Headers.AcceptEncoding.TryParseAdd(parsedHeaders["Accept-Encoding"]);
                        // Console.WriteLine($"Accept Encoding Added? {isAccept}");
                        requestMessage.Headers.AcceptLanguage.TryParseAdd(parsedHeaders["Accept-Language"]);
                        // requestMessage.Headers.CacheControl = CacheControlHeaderValue.;
                        requestMessage.Headers.UserAgent.ParseAdd(parsedHeaders["User-Agent"]);
                        requestMessage.Headers.Connection.TryParseAdd(parsedHeaders["Connection"]);
                        requestMessage.Headers.Add("Cookie", parsedHeaders["Cookie"]);
                        requestMessage.Headers.Upgrade.ParseAdd(parsedHeaders["Upgrade-Insecure-Requests"]);

                        // requestMessage.Content.Headers.Add("Host", parsedHeaders["Host"]);
                        
                    }
                    catch (Exception)
                    {
                        throw;
                    }
                    requestMessage.RequestUri = new Uri(url);

                    try
                    {
                        string? resultWeb = ""; 
                        string? tempContType;
                        Response obj;

                        var responseMessage = await _httpCl.SendAsync(requestMessage, HttpCompletionOption.ResponseContentRead, CancellationToken.None);   
                        responseMessage.Headers.Remove("transfer-encoding");
                        
                        // Console.WriteLine(responseMessage.Headers);
                        // var linkParser = new Regex(@"\b(?:https?://|www\.)\S+\b", RegexOptions.Compiled | RegexOptions.IgnoreCase);
                        // foreach (Match link in linkParser.Matches(resultWeb))
                        // {
                        //     Console.WriteLine(link.Value);
                        // }
                        // Serialize Response Object
                        
                        if(string.IsNullOrEmpty(responseMessage.Content.Headers.ContentType?.CharSet)){
                            tempContType = responseMessage.Content.Headers.ContentType?.MediaType;
                            
                        }else {
                            tempContType = $"{responseMessage.Content.Headers.ContentType?.MediaType};charset={responseMessage.Content.Headers.ContentType?.CharSet}";
                            
                        }
                        
                        // Console.WriteLine(responseMessage.Content.ReadAsStringAsync().Result);

                        if ((bool)responseMessage.Content.Headers.ContentType?.MediaType.Contains("image"))
                        {
                            var bytContent = await responseMessage.Content.ReadAsByteArrayAsync();
                            // resultWeb = "data:image/png;base64," + Convert.ToBase64String(bytContent);
                            resultWeb = Convert.ToBase64String(bytContent);
                        }else
                        {
                            // resultWeb  = responseMessage.Content.ReadAsStringAsync().Result;
                            var bytContent  = await responseMessage.Content.ReadAsByteArrayAsync();
                            resultWeb = Convert.ToBase64String(bytContent);
                        }

                        obj = new Response
                        {
                            cliID = DeRep.cliID,
                            method = DeRep.method,
                            response = resultWeb,
                            headers = responseMessage.Headers.ToString(),
                            contentType = tempContType,
                            request = DeRep.request
                        };

                        var jsonReq = JsonConvert.SerializeObject(obj);
                        
                        var ResBytes = Encoding.UTF8.GetBytes(jsonReq);
                        Console.WriteLine($"\n\nResponse Headers: {responseMessage.StatusCode}\r\n{responseMessage.Headers.ToString()}");
                        Console.WriteLine($"Content-Type: {responseMessage.Content.Headers.ContentType?.MediaType};{responseMessage.Content.Headers.ContentType?.CharSet}");
                            
                        // Thread.Sleep(2000);
                        await socket.SendAsync(new ArraySegment<byte>(ResBytes),WebSocketMessageType.Binary, true, CancellationToken.None);

                        // await socket.CloseOutputAsync()

                    }
                    catch (Exception)
                    {
                        Console.WriteLine("Could no fetch website link...");
                    }
                    
                    
                    
                  }else {
                    Console.WriteLine($"Receive: {response}");
                  }
                }
            }
        }

        private static ConcurrentDictionary<string, string> GetConfigData()
        {
            ConcurrentDictionary<string, string> storage = new ConcurrentDictionary<string, string>();

            var handle = File.ReadAllText(@"config.ini");
            // Console.WriteLine($"Read: {handle.TrimEnd()}");
            string[] settings = handle.TrimEnd().Split(Environment.NewLine);
            // Console.WriteLine(settings.LongLength);
            foreach(var line in settings)
            {
            //   Console.WriteLine("Line: {0}", line);
                if(line != Environment.NewLine || line != string.Empty){
                    var getKeyValue = line.Split('=');
                    storage.TryAdd(getKeyValue[0], getKeyValue[1]);
                    // Console.WriteLine($"Value: {getKeyValue[0]}:{getKeyValue[1]}");
                }

            }
            return storage;
        }
        private static ConcurrentDictionary<string, string> GetHeaders(string headers)
        {
            ConcurrentDictionary<string, string> storage = new ConcurrentDictionary<string, string>();

            // Console.WriteLine($"Read: {headers.TrimEnd('\r').TrimEnd('\n')}");
            string[] settings = headers.TrimEnd('\r').TrimEnd('\n').Split("\n");
            // Console.WriteLine(settings.LongLength);

            for (int i = 2; i < settings.Length - 2; i++)
            {
                
                var getKeyValue = settings[i].Trim().Split(':');
                if (settings[i].Contains("User-Agent:") || settings[i].Contains("Host:"))
                {
                    var agent_value = settings[i].Trim().Substring(getKeyValue[0].Length + 1);
                    storage.TryAdd(getKeyValue[0], agent_value);   
                    // Console.WriteLine($"Key: {getKeyValue[0]}:{agent_value}");
                }else {
                    storage.TryAdd(getKeyValue[0], getKeyValue[1]);
                    // Console.WriteLine($"Key: {getKeyValue[0]}:{getKeyValue[1]}");
                }
                
                
            }
            return storage;
        }

        public static string Base64Enc(string str)
        {
            var byteStr = encoding.GetBytes(str);
            return Convert.ToBase64String(byteStr);
        }
        
        public static string ConstructQueryString(NameValueCollection parameters)
        {
            List<string> items = new List<string>();

            foreach (string name in parameters)
                items.Add(string.Concat(name, "=", HttpUtility.UrlEncode(parameters[name])));

            return string.Join("&", items.ToArray());
        }
         
        public static string DecodeQueryString(NameValueCollection parameters)
        {
            List<string> items = new List<string>();

            foreach (string name in parameters)
                items.Add(string.Concat(name, ":", parameters[name]));

            return string.Join("\n", items.ToArray());
        }

        public static NameValueCollection? parseQuery(string queryString)
        {
            NameValueCollection headers = new NameValueCollection();
            string[] tempCollect = queryString.Split('&');
            foreach (var header in tempCollect)
            {
                // if (!string.IsNullOrEmpty(header))
                // {
                    var headerKey = header.Split('=')[0];
                    var headerValue = HttpUtility.UrlDecode(header.Split('=')[1]);
                    // Console.WriteLine($"{headerKey}: {headerValue}");
                    headers.Set(headerKey, headerValue);
                // }
                
            }
            return headers;
        }
    }
}
