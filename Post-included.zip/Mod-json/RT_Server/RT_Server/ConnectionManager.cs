using System.Net.WebSockets;
using System.Collections.Generic;
using System.Collections.Concurrent;

namespace RT_Server {
    public class ConnectionManager {
        private ConcurrentDictionary<string, WebSocket> _sockets = new ConcurrentDictionary<string, WebSocket>();
        public string? _id {get; set;}

        public WebSocket GetSocketById(string id)
        {
            return _sockets.FirstOrDefault(p => p.Key == id).Value;
        }

        public string SetSocketId(WebSocket socket, string new_id)
        {
            WebSocket __socket;
            // check if exists socket
            var old_id = GetId(socket);
            if(old_id != string.Empty || old_id != null)
            {
                var sockExist = GetSocketById(old_id);
                if(sockExist != null){
                    // remove the previous socket from dictionary
                    // and add new id for the socket
                    var cond_rem = _sockets.TryRemove(old_id, out __socket);
                    if(cond_rem)
                    {   
                        AddSocket(__socket, new_id);
                        return $"Client {old_id} Set to new id {new_id}";
                    }
                }
                return $"Error resetting ClientID: {old_id}";
            }
            return $"Error resetting ClientID: {old_id}";
        }

        public ConcurrentDictionary<string, WebSocket> GetAll()
        {
            return _sockets;
        }

        public string GetId(WebSocket socket)
        {
            return _sockets.FirstOrDefault(p => p.Value == socket).Key;
        }

        public void AddSocket(WebSocket socket, string id)
        {
            // _id = CreateConnectionId();
            _id = id;
            _sockets.TryAdd(_id, socket);
        }

        public async Task RemoveSocket(string id)
        {
            WebSocket? socket = null;
            _sockets.TryRemove(id, out socket);

            await socket.CloseAsync(closeStatus: WebSocketCloseStatus.NormalClosure, statusDescription: "Closed by the ConnectonManager", cancellationToken: CancellationToken.None);
        }

        public string CreateConnectionId()
        {
            return Guid.NewGuid().ToString();
        }
    }
}
