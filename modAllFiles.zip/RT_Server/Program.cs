﻿namespace RT_Server
{

    public class Program {

        // public static WebSocketHandler _socketHandler { get; set;}

        static void Main(string[] args)
        {
            string host;

            if(args.Length < 1){
                Console.WriteLine("Usage: RT_Server {host:port}");
                System.Environment.Exit(1);
                host = "localhost:41592";
            }else {
                host = args[0];
            }
            // int port = 8011;
            SocketServerHandler StartListener = new SocketServerHandler();

            StartListener.Run($"http://{host}/");

            Console.WriteLine("Press any key to exit server...");
            Console.ReadKey();

        }
    }
}
