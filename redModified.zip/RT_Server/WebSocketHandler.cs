using System;
using System.Linq;
using System.Net.WebSockets;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Text;

namespace RT_Server {

  public class WebSocketHandler {
    protected ConnectionManager _webSocketmanager = new ConnectionManager();

    public void OnConnected(WebSocket socket, string id)
    {
        _webSocketmanager.AddSocket(socket, id);
    }

    public async Task OnDisconnected(WebSocket socket)
    {
      await _webSocketmanager.RemoveSocket(_webSocketmanager.GetId(socket));
    }

    public string _getID(WebSocket _socket)
    {
      return _webSocketmanager.GetId(_socket);
    }

    public string _setID(WebSocket _socket, string newID)
    {
      return _webSocketmanager.SetSocketId(_socket, newID);
    }

    public WebSocket _getSocket(string id)
    {
      return _webSocketmanager.GetSocketById(id);
    }

    public string CreateConnectionId()
    {
        return Guid.NewGuid().ToString();
    }


  }

}
