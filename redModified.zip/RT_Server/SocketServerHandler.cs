using System.Collections.Concurrent;
using System.Collections.Specialized;
using System.Net;
using System.Net.WebSockets;
using System.Text;
using System.Text.RegularExpressions;
using System.Web;

namespace RT_Server
{
    public class SocketServerHandler {

        public WebSocketHandler _socketHandler  = new WebSocketHandler();
        // public ConcurrentDictionary<string, Stream> storage = new ConcurrentDictionary<string, Stream>();
        public ConcurrentDictionary<string, HttpListenerContext> _httpReqLists = new ConcurrentDictionary<string,HttpListenerContext>();
        private static UTF8Encoding encoding = new UTF8Encoding();

        private static HttpListener _listener = new HttpListener();

        public string? baseUrl;

        public string? initial_url = "";

        public StringBuilder setRTC = new StringBuilder();

        public async void Run(string _httpListener_prefix)
        {
            baseUrl = _httpListener_prefix;
            setRTC.Append("<!DOCTYPE html>");
            setRTC.Append("<html><head><title>Cookie Setter</title><meta charset=\"UTF-8\"><meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\"></head>");
            setRTC.Append("<body><h1>PAT RTC</h1><label for=\"url\">Website URL:</label><input type=\"text\" id=\"url\" name=\"url\" value=\"http://anankin2.ddns.net:8000\"><br>");
            setRTC.Append("<label for=\"clientId\">Client ID:</label><input type=\"text\" id=\"clientId\" name=\"clientId\" value=\"12\"><br>");
	        setRTC.Append("<button onclick=\"setCookiesAndRedirect()\">Submit</button>");
            setRTC.Append("<script>");
            // setRTC.Append("function base64Encode(str){var bytes = []; for (var i = 0; i < str.length; ++i){ var charCode = str.charCodeAt(i); bytes.push(charCode & 0xFF);");
            // setRTC.Append("bytes.push((charCode & 0xFF00) >>> 8);} var len = bytes.length; var buffer = \"\"; for (var i = 0; i < len; i++){buffer += String.fromCharCode(bytes[i]);}");
            setRTC.Append("function arrayBufferToBase64(buffer) {var binary = \'\';var bytes = new Uint8Array(buffer);var len = bytes.byteLength;for (var i = 0; i < len; i++) {binary += String.fromCharCode(bytes[i]);}return window.btoa(binary);}");
            setRTC.Append("function base64Encode(str){ var textEncoder = new TextEncoder('utf-8'); var buffer = textEncoder.encode(str);");
            setRTC.Append("return arrayBufferToBase64(buffer);}");     
            setRTC.Append("function setCookiesAndRedirect() {var url = document.getElementById(\"url\").value;");
            setRTC.Append("var clientId = document.getElementById(\"clientId\").value;document.cookie = \"pattoken =\" + base64Encode(url + \";\" + clientId) +\";\";setTimeout(function () {window.location.href = \"/\";}, 2000);}</script></body></html>");
            
            // _listener.TimeoutManager.MinSendBytesPerSecond = UInt32.MaxValue;
            
            _listener.Prefixes.Add(baseUrl);
            _listener.Start();

            Console.WriteLine($"Listening on {baseUrl}");

            

            while(true)
            {
                try
                {
                    var _context = await _listener.GetContextAsync();
                    // create a new Request Connection id
                    var _reqId = _socketHandler.CreateConnectionId();

                    // save id and context
                    _httpReqLists.TryAdd(_reqId, _context);

                    if(_context.Request.IsWebSocketRequest)
                    {
                        // Handle Web Socket Request Here
                        HandleSocketRequest(_context);
                    }else {
                        
                        // This is a http request handler from browser
                        // _context.Response.StatusCode = 200;
                        // get the client id from uri
                        string? urln ="";
                        string? raw_urln = "";
                        var getCliID = "";
                        
                        var headers = _context.Request.Headers.ToString();
                        if(_context.Request.RawUrl != null){
                            urln = _context.Request.RawUrl;
                            // Console.WriteLine(urln);
                            raw_urln = _context.Request.RawUrl;
                            if (headers.Contains("pattoken") == false)
                            {
                                _context.Response.ContentType = "text/html;Charset=utf-8;";
                                _context.Response.StatusCode = 200;
                                _context.Response.ContentLength64 = setRTC.Length;
                                var homeBytes = encoding.GetBytes(setRTC.ToString());
                                await _context.Response.OutputStream.WriteAsync(homeBytes, 0, homeBytes.Length);
                                await _context.Response.OutputStream.FlushAsync();
                                _context.Response.OutputStream.Close();
                            } else {
                                // Parse the request to get the server URL and the cookie value
                                string[] lines = headers.Split(new string[] { "\r\n" }, StringSplitOptions.None);
                                
                                
                                foreach (string line in lines)
                                {
                                    if (line.StartsWith("Cookie:"))
                                    {
                                        String line2 = line.Substring(7).Trim();
                                        string[] cookies = line2.Split(new string[] { ";" }, StringSplitOptions.None);

                                        if (line.Contains("patredtoken"))
                                        {
                                            foreach (string cookie in cookies)
                                            {
                                                string[] data = cookie.Trim().Split(new String[] { "="}, StringSplitOptions.None);
                                            
                                                if (data[0].Trim() == "patredtoken")
                                                {
                                                    string token = cookie.Substring(cookie.IndexOf("=")+1);
                                                    var decodedToken = Base64Dec(token.Trim());
                                                    
                                                    string[] data2 = decodedToken.Trim().Split(new string[]{";"}, StringSplitOptions.None);
                                                    urln = data2[0].Trim();
                                                    initial_url = urln;

                                                    getCliID = data2[1].Trim();

                                                }
                                            }
                                        } else
                                        {
                                            foreach (string cookie in cookies)
                                            {
                                                string[] data = cookie.Trim().Split(new String[] { "="}, StringSplitOptions.None);
                                            
                                                if (data[0].Trim() == "pattoken")
                                                {
                                                    string token = cookie.Substring(cookie.IndexOf("=")+1);
                                                    var decodedToken = Base64Dec(token.Trim());
                                                    
                                                    string[] data2 = decodedToken.Trim().Split(new string[]{";"}, StringSplitOptions.None);
                                                    urln = data2[0].Trim();
                                                    initial_url = urln;

                                                    getCliID = data2[1].Trim();

                                                    // Console.WriteLine($"ClientId: {getCliID} Url:{urln}");
                                                }
                                            }
                                        }
                                        
                                    }
                                }

                                
                                
                                if (raw_urln.Length>0)
                                {
                                    if (raw_urln.StartsWith('/'))
                                    {
                                        urln += raw_urln;
                                    }
                                    else
                                    {
                                        if (raw_urln.EndsWith('/'))
                                        {
                                            urln += raw_urln;
                                        }
                                        else
                                        {
                                            urln += "/" +raw_urln;
                                        }
                                    }	
                                }
                            }

                            Console.WriteLine($"ClientId: {getCliID} Url:{urln}, RawUrl: {raw_urln}");
                                
                            // check if client ID exists
                            var cliSocket = _socketHandler._getSocket(getCliID);
                            if(cliSocket != null)
                            {
                                try 
                                {
                                    
                                    Console.WriteLine("Request Headers\r\n");
                                    Console.WriteLine($"{_context.Request.HttpMethod} {urln} HTTP/{_context.Request.ProtocolVersion}\r\n");
                                    Console.WriteLine(headers);
                                    
                                    
                                    string content = "";
                                    long contentLength = 0;
                                    if (_context.Request.HasEntityBody)
                                    {
                                        // Content Body
                                        // Console.WriteLine($"Content-Type: {_context.Request.ContentType} Length: {_context.Request.ContentLength64}");
                                        StreamReader streamReader = new StreamReader(_context.Request.InputStream);
                                        content = await streamReader.ReadToEndAsync();
                                        contentLength = _context.Request.ContentLength64;
                                    }
                                    // Set all headers and values into class field
                                    var obj = new Response
                                    {
                                        cliID = _reqId,
                                        method = _context.Request.HttpMethod,
                                        response = content,
                                        headers = ConstructQueryString(_context.Request.Headers),
                                        request = urln,
                                        contentType = _context.Request.ContentType,
                                        protocol = _context.Request.ProtocolVersion.ToString(),
                                        statusCode = 200,
                                        contentLength = contentLength,
                                        location = "",
                                        cid = getCliID
                                    };
                                    var jsonReq = Newtonsoft.Json.JsonConvert.SerializeObject(obj);

                                    byte[] bRequest = encoding.GetBytes(jsonReq);
                                    
                                    await cliSocket.SendAsync(new ArraySegment<byte>(bRequest), WebSocketMessageType.Binary, true, CancellationToken.None);
                                        
                                } catch (Exception ex) {
                                    Console.WriteLine($"HttpRequest Error: {ex.HResult}");
                                }
                            }

                            }
                            
                    }
                
                }
                catch (System.Exception ex)
                {
                    // _httpReqLists.Clear();
                    Console.WriteLine($"Error occured finally {ex.StackTrace}");
                    continue;
                }
                
            }
        }

        // Handle WebSocket Request
        private async void HandleSocketRequest(HttpListenerContext _httpContext)
        {
            WebSocketContext? _webSocketCxt = null;

            try
            {
                _webSocketCxt = await _httpContext.AcceptWebSocketAsync(null);
                string ip = _httpContext.Request.RemoteEndPoint.Address.ToString();
                Console.WriteLine($"Connected: {ip}");

            } catch (Exception ex) {
                _httpContext.Response.StatusCode = 500;
                _httpContext.Response.Close();
                Console.WriteLine($"Request Handling failed: {ex.Data}");
                return;
            }

            WebSocket _socket = _webSocketCxt.WebSocket;
            // OnConnected(_socket);
            byte[]? buf = new byte[1024];
            try
            {
                await _socket.ReceiveAsync(new ArraySegment<byte>(buf), CancellationToken.None);
            }
            catch (System.Exception ex)
            {
                
                Console.WriteLine($"Receive Error: {ex.Data}");
            }
            
            var getCli = Encoding.UTF8.GetString(buf).TrimEnd('\0');
            _socketHandler.OnConnected(_socket, getCli);
            Console.WriteLine($"ClientID: {_socketHandler._getID(_socket)}");
            buf = null;

            try {

                while (_socket.State == WebSocketState.Open)
                {
                    var rcvBuffer = new ArraySegment<byte>(new byte[8192]);
                    var totalBytes = new List<byte>();
                    WebSocketReceiveResult? data = null;

                    do {
                        data = await _socket.ReceiveAsync(rcvBuffer, CancellationToken.None);
                        for (int i=0; i < data.Count; i++)
                        {
                            totalBytes.Add(rcvBuffer.Array[i]);
                        }
                    } while(!data.EndOfMessage);
                    
                    var recvData = Encoding.UTF8.GetString(totalBytes.ToArray(), 0, totalBytes.Count).TrimEnd('\0');

                    
                    if(recvData.StartsWith("SET ")){

                        var reply = _socketHandler._setID(_socket, recvData.Split(" ")[1]);
                        Console.WriteLine($"Set ID: {reply}");
                        Console.WriteLine("<==========End of Reply==========>");
                    }else {
                        Response?  DeRep;
                        bool isRedirect = false;

                        DeRep = Newtonsoft.Json.JsonConvert.DeserializeObject<Response>(recvData);
                        if(DeRep != null){
                            Console.WriteLine($"Response Headers: {DeRep.statusCode}\r\n");
                            

                            HttpListenerContext? _resContext = null;
                            if(DeRep.cliID != null)
                                _httpReqLists.TryGetValue(DeRep.cliID, out _resContext);

                            byte[]? respBytes = null;
                            if(DeRep.response != null)
                                respBytes = Convert.FromBase64String(DeRep.response);
                            else
                                Console.WriteLine("Response is null i.e No Content");
                            
                            if(DeRep.contentType != null && DeRep.contentType.Contains("text/html"))
                            {
                                string tempData = "";
                                
                                if(respBytes != null)
                                tempData = encoding.GetString(respBytes);

                                string pattern = "<META.*?>"; // Regular expression pattern to match the META tag

                                Match match = Regex.Match(tempData, pattern); // Find the first match

                                if (match.Success)
                                {
                                    string metaTag = match.Value; // Get the matched value
                                    // Console.WriteLine(metaTag); // Output: "<META http-equiv=Refresh content="0; URL=http://anankin2.ddns.net:8000/rps/">"
                                    if(metaTag.Contains("http-equiv=Refresh") && metaTag.Contains("URL="))
                                    {
                                        string pattern2 = "URL=(.*?)\""; // Regular expression pattern to match the URL

                                        Match match2 = Regex.Match(metaTag, pattern2); // Find the first match

                                        if (match2.Success)
                                        {
                                            string url2 = match2.Groups[1].Value; // Get the captured group
                                            // Console.WriteLine(url2); // Output: "http://anankin2.ddns.net:8000/rps/"
                                            if(url2.StartsWith("http"))
                                            {
                                                var getDomain2 = getDomain(url2);
                                                var getPath = getQueryAndPath(url2);
                                                var newtoken1 = $"{getDomain2};{DeRep.cid}";

                                                if(getPath.EndsWith('/'))
                                                    getPath = getPath.TrimEnd('/');

                                                var injectScript = $"<script>window.location.href = '{String.Concat(baseUrl.Substring(0, baseUrl.Length-1), getPath)}';</script>";
                                                    
                                                // var newtoken = String.Concat("patredtoken=",Base64Enc(newtoken1),";");
                                                var newtoken2 = String.Concat("pattoken=",Base64Enc(newtoken1),";");

                                                // Console.WriteLine($"Token: {newtoken}, InitialUrl:{initial_url}, NewDomain:{url2}, Domain: {getDomain2}");

                                                initial_url = getDomain2;
                                                
                                                // tempData = tempData.Replace(getDomain2, baseUrl.Substring(0, baseUrl.Length-1));
                                                tempData = tempData.Replace(metaTag, "");
                                                int index = tempData.LastIndexOf("</HEAD>"); /// find the last of enclosing tag (html)

                                                if (index != -1)
                                                {
                                                    string output = tempData.Insert(index, injectScript);
                                                    Console.WriteLine(output);
                                                }
                                                // _resContext.Response.Headers.Add(HttpResponseHeader.SetCookie, newtoken);
                                                _resContext.Response.Headers.Add(HttpResponseHeader.SetCookie, newtoken2);
                                                _resContext.Response.Headers.Add(HttpResponseHeader.Location, String.Concat(baseUrl.Substring(0, baseUrl.Length-1), getPath));
                                                // DeRep.statusCode = 302;
                                                // isRedirect = true;
                                            }
                                                
                                        }
                                    }
                                }
                                
                                if(!String.IsNullOrEmpty(initial_url))
                                if(tempData.Contains(initial_url))
                                {
                                    tempData = tempData.Replace(initial_url, baseUrl);
                                }
                                
                                
                                respBytes = encoding.GetBytes(tempData);
                            }

                            NameValueCollection? tmpHeaders = new();
                            if(String.IsNullOrEmpty(DeRep.headers) == false)
                            {
                                NameValueCollection? parameters = parseQuery(DeRep.headers);
                                tmpHeaders = parameters;
                                Console.WriteLine($"{DeRep.headers}");
                                if(_resContext != null && (parameters != null)){
                                    if(DeRep.headers.Contains("Set-Cookie") == true)
                                        _resContext.Response.Headers.Add(HttpResponseHeader.SetCookie,parameters["Set-Cookie"]);
                                    
                                    if((parameters["Set-Cookie"] != null) && DeRep.headers.Contains("Set-Cookie") && DeRep.headers.Contains("iR="))
                                    {
                                        var index_iR = parameters["Set-Cookie"].IndexOf("iR=");
                                        var from_iRValue = parameters["Set-Cookie"].Substring(index_iR);
                                        _resContext.Response.Headers.Add(HttpResponseHeader.SetCookie, from_iRValue);
                                        // Console.WriteLine($"\r\nIR-Value: {from_iRValue}\r\n");
                                    }

                                    if(DeRep.headers.Contains("Keep-Alive") == true)
                                        _resContext.Response.Headers.Add(HttpResponseHeader.KeepAlive,parameters["Keep-Alive"]);
                                    if(DeRep.headers.Contains("Connection") == true)
                                        _resContext.Response.Headers.Add(HttpResponseHeader.Connection,parameters["Connection"]);
                                    if(DeRep.headers.Contains("Date") == true)
                                        _resContext.Response.Headers.Add(HttpResponseHeader.Date,parameters["Date"]);
                                    if(DeRep.headers.Contains("Server") == true)
                                        _resContext.Response.Headers.Add(HttpResponseHeader.Server,parameters["Server"]);
                                    if(DeRep.headers.Contains("X-Frame-Options") == true)
                                        _resContext.Response.Headers.Add("X-Frame-Options",parameters["X-Frame-Options"]);
                                    if(DeRep.headers.Contains("Expires") == true)
                                        _resContext.Response.Headers.Add(HttpResponseHeader.Expires,parameters["Expires"]);

                                    if(DeRep.headers.Contains("Content-Length") == true)
                                        _resContext.Response.Headers.Add(HttpResponseHeader.ContentLength,parameters["Content-Length"]);
                                    if(DeRep.headers.Contains("Pragma") == true)
                                        _resContext.Response.Headers.Add(HttpResponseHeader.Pragma,parameters["Pragma"]);
                                    if(DeRep.headers.Contains("X-XSS-Protection") == true)
                                        _resContext.Response.Headers.Add("X-XSS-Protection", parameters["X-XSS-Protection"]);
                                    if(DeRep.headers.Contains("Access-Control-Allow-Origin") == true)
                                        _resContext.Response.Headers.Add("Access-Control-Allow-Origin", parameters["Access-Control-Allow-Origin"]);

                                    if(DeRep.headers.Contains("Access-Control-Allow-Methods") == true)
                                        _resContext.Response.Headers.Add("Access-Control-Allow-Methods", parameters["Access-Control-Allow-Methods"]);

                                    if(DeRep.headers.Contains("Access-Control-Allow-Credentials") == true)
                                        _resContext.Response.Headers.Add("Access-Control-Allow-Credentials", parameters["Access-Control-Allow-Credentials"]);

                                    _resContext.Response.ContentLength64 = (long)DeRep.contentLength;
                                    if(DeRep.headers.Contains("Location") == true)
                                    {
                                        var redirectLocation = Base64Dec(DeRep.location);
                                        
                                        
                                        if(String.IsNullOrEmpty(redirectLocation) == false && (initial_url != null)){
                                            // Get the domain of redirection and Location
                                            if (redirectLocation.StartsWith("http:") || redirectLocation.StartsWith("https:"))
                                            {
                                                string redirectLocationDomain = getDomain(redirectLocation.Trim());
                                                if (!redirectLocationDomain.Equals(initial_url.Trim()))
                                                {
                                                    redirectLocation = redirectLocation.Replace(initial_url.Trim(), redirectLocationDomain);

                                                    var newtoken1 = $"{redirectLocationDomain};{DeRep.cid}";
                                                    
                                                    var newtoken = String.Concat("patredtoken=",Base64Enc(newtoken1),";");

                                                    Console.WriteLine($"Token: {newtoken}, InitialUrl:{initial_url}, NewDomain:{redirectLocationDomain}");

                                                    initial_url = redirectLocationDomain;

                                                    _resContext.Response.Headers.Add(HttpResponseHeader.SetCookie, newtoken);
                                                }
                                            }
                                            
                                            var tempUrl = initial_url.Substring(initial_url.IndexOf("//")+1);
                                            redirectLocation = redirectLocation.Replace(initial_url,"").Replace(tempUrl,"");
                                            Console.WriteLine($"Redirect Location: {redirectLocation}, Init: {initial_url}");
                                        }
                                        
                                        
                                        _resContext.Response.Headers.Add(HttpResponseHeader.Location,redirectLocation);
                                    }
                                        
                                            
                                        
                                }
                                
                            }
                                
                            if ((int?)DeRep.statusCode == 404)
                            {
                                if(_resContext != null){
                                    _resContext.Response.StatusCode = (int)DeRep.statusCode;
                                    _resContext.Response.OutputStream.Flush();
                                    await _resContext.Response.OutputStream.DisposeAsync();
                                }
                                
                            }else if(((int?)DeRep.statusCode == 307) || ((int?)DeRep.statusCode == 302) || ((int?)DeRep.statusCode == 301))
                            {
                                if(_resContext != null){
                                    // if(isRedirect)
                                    //     _resContext.Response.StatusCode = 307;
                                    // else
                                        _resContext.Response.StatusCode = (int)DeRep.statusCode;

                                    
                                    // _resContext.Response.RedirectLocation = tmpHeaders["Location"];
                                    _resContext.Response.OutputStream.Flush();
                                    await _resContext.Response.OutputStream.DisposeAsync();
                                    // isRedirect = false;
                                }
                            }
                            else {
                                // Console.WriteLine($"{encoding.GetString(respBytes)}");
                                Console.WriteLine($"Content-Type: {DeRep.contentType}");
                                if(_resContext != null){
                                    if(!String.IsNullOrEmpty(DeRep.contentType))
                                    _resContext.Response.ContentType = DeRep.contentType;
                                    if(DeRep.statusCode != null)
                                    _resContext.Response.StatusCode = (int)DeRep.statusCode;
                                    
                                    // Console.WriteLine(encoding.GetString(respBytes));
                                    try
                                    {
                                        if(respBytes != null)
                                        await _resContext.Response.OutputStream.WriteAsync(respBytes, 0, respBytes.Length);
                                        _resContext.Response.OutputStream.Flush();
                                    // await _resContext.Response.OutputStream.DisposeAsync();
                                        // _resContext.Response.OutputStream.Close();
                                    }
                                    catch (Exception ex)
                                    {
                                        Console.WriteLine($"{ex.StackTrace}");
                                    } 
                                    
                                }
                                
                            }
                            
                            
                        }
                        
                    }

                    if(data.MessageType == WebSocketMessageType.Close)
                     {   
                        Console.WriteLine("Error occured");
                        await _socket.CloseAsync(WebSocketCloseStatus.NormalClosure, "", CancellationToken.None);
                   } 
                }
            } catch (Exception ex) {
                Console.WriteLine($"Error: {ex.StackTrace}");

                await _socketHandler.OnDisconnected(_socket);
                Console.WriteLine("A client got disconnected...");
            } finally {
                if(_socket != null)
                    _socket.Dispose();
            }
        }

        public static string Base64Dec(string? encoded)
        {
            byte[]? byteStr = null;
            if(String.IsNullOrEmpty(encoded) == false)
                byteStr = Convert.FromBase64String(encoded);
            if(byteStr != null)
                return encoding.GetString(byteStr);

            return String.Empty;
        }

        public static string Base64UniDec(string? encoded)
        {
            byte[]? byteStr = null;
            if(String.IsNullOrEmpty(encoded) == false)
                byteStr = Convert.FromBase64String(encoded);
            if(byteStr != null)
                return Encoding.Unicode.GetString(byteStr);

            return String.Empty;
        }

        public static string Base64Enc(string? str)
        {
            byte[]? byteStr = null;
            if(!String.IsNullOrEmpty(str))
            byteStr = encoding.GetBytes(str);

            if(byteStr != null)
            return Convert.ToBase64String(byteStr);

            return String.Empty;
        }

        public static string ConstructQueryString(NameValueCollection parameters)
        {
            List<string> items = new List<string>();

            foreach (string name in parameters)
                items.Add(string.Concat(name, "=", HttpUtility.UrlEncode(parameters[name])));

            return string.Join("&", items.ToArray());
        }

        public static NameValueCollection? parseQuery(string queryString)
        {
            string v = queryString.TrimEnd(new char[]{'\r','\n'});
            queryString = v.Replace(": ", "=").Replace("\r\n", "&");


            NameValueCollection headers = new NameValueCollection();
            string[] tempCollect = queryString.Split('&');
            foreach (var header in tempCollect)
            {
                var headerKey = header.Split('=')[0];
                var headerValue = header.Substring(header.IndexOf('=')+1);
                headers.Set(headerKey, headerValue);
            }
            return headers;
        }

        private static string getDomain(string url)
        {
            string domain = "";
            try
            {
               Uri uri = new(url);
               bool hasPort = uri.Port != 80 && uri.Port != 443;

               if (hasPort)
                    domain = String.Concat(uri.Scheme,"://",uri.Host,String.Concat(":",uri.Port.ToString()));
               else
                    domain = String.Concat(uri.Scheme,"://",uri.Host);
               
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Invalid URL: {ex.Data}");
            }
            

            return domain;
        }

        private static string getQueryAndPath(string url)
        {
            string path = "";
            try
            {
                Uri uri = new(url);
                path = uri.PathAndQuery;
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Invalid URL: {ex.Data}");
            }
            

            return path;
        }
    }
}
