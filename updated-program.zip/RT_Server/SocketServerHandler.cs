using System.Collections.Concurrent;
using System.Collections.Specialized;
using System.Net;
using System.Net.WebSockets;
using System.Text;
using System.Web;

namespace RT_Server
{
    public class SocketServerHandler {

        public WebSocketHandler _socketHandler  = new WebSocketHandler();
        public ConcurrentDictionary<string, Stream> storage = new ConcurrentDictionary<string, Stream>();
        public ConcurrentDictionary<string, HttpListenerContext> _httpReqLists = new ConcurrentDictionary<string,HttpListenerContext>();
        private static UTF8Encoding encoding = new UTF8Encoding();
        public string? baseUrl;

        public async void Run(string _httpListener_prefix)
        {
            baseUrl = _httpListener_prefix;
            HttpListener _listener = new HttpListener();
            _listener.TimeoutManager.MinSendBytesPerSecond = UInt32.MaxValue;
            
            _listener.Prefixes.Add(baseUrl);
            _listener.Start();

            Console.WriteLine($"Listening on {baseUrl}");

            while(true)
            {
                var _context = await _listener.GetContextAsync();
                // create a new Request Connection id
                var _reqId = _socketHandler.CreateConnectionId();

                // save id and context
                _httpReqLists.TryAdd(_reqId, _context);

                if(_context.Request.IsWebSocketRequest)
                {
                    // Handle Web Socket Request Here
                    HandleSocketRequest(_context);
                }else {
                    
                    // This is a http request handler from browser
                    _context.Response.StatusCode = 200;
                    // get the client id from uri
                    string? urln ="";
                    if(_context.Request.RawUrl != null)
                        urln = _context.Request.RawUrl;
                    
                    var getCliID = urln.Split("/")[1];
                    // check if client ID exists
                    var cliSocket = _socketHandler._getSocket(getCliID);
                    if(cliSocket != null)
                    {
                        try {
                                Console.WriteLine("Request Headers\r\n");
                                Console.WriteLine($"{_context.Request.HttpMethod} {urln} HTTP/{_context.Request.ProtocolVersion}\r\n");
                                Console.WriteLine(_context.Request.Headers.ToString());
                                
                                
                                string content = "";
                                Dictionary<string, string> headersAll = new Dictionary<string, string>();
                                
                                if (_context.Request.HasEntityBody)
                                {
                                    // Content Body
                                    Console.WriteLine($"Content-Type: {_context.Request.ContentType}");
                                    StreamReader streamReader = new StreamReader(_context.Request.InputStream);
                                    content = streamReader.ReadToEnd();
                                    Console.WriteLine(content);
                                }
                                // Set all headers and values into dictionary
                                var obj = new Response
                                {
                                    cliID = _reqId,
                                    method = _context.Request.HttpMethod,
                                    response = content,
                                    headers = ConstructQueryString(_context.Request.Headers),
                                    request = urln,
                                    contentType = _context.Request.ContentType,
                                    protocol = _context.Request.ProtocolVersion.ToString(),
                                    statusCode = 200
                                };
                                var jsonReq = Newtonsoft.Json.JsonConvert.SerializeObject(obj);

                                byte[] bRequest = encoding.GetBytes(jsonReq);
                                
                                await cliSocket.SendAsync(new ArraySegment<byte>(bRequest), WebSocketMessageType.Binary, true, CancellationToken.None);

                                
                        } catch (Exception ex) {
                            Console.WriteLine($"HttpRequest Error: {ex.HResult}");
                        }
                    }

                }
            }
        }

        // Handle WebSocket Request
        private async void HandleSocketRequest(HttpListenerContext _httpContext)
        {
            WebSocketContext? _webSocketCxt = null;

            try
            {
                _webSocketCxt = await _httpContext.AcceptWebSocketAsync(null);
                string ip = _httpContext.Request.RemoteEndPoint.Address.ToString();
                Console.WriteLine($"Connected: {ip}");

            } catch (Exception ex) {
                _httpContext.Response.StatusCode = 500;
                _httpContext.Response.Close();
                Console.WriteLine($"Request Handling failed: {ex}");
                return;
            }

            WebSocket _socket = _webSocketCxt.WebSocket;
            // OnConnected(_socket);
            byte[]? buf = new byte[1024];
            try
            {
                await _socket.ReceiveAsync(new ArraySegment<byte>(buf), CancellationToken.None);
            }
            catch (System.Exception ex)
            {
                
                Console.WriteLine($"Receive Error: {ex.Message}");
            }
            
            var getCli = Encoding.UTF8.GetString(buf).TrimEnd('\0');
            _socketHandler.OnConnected(_socket, getCli);
            Console.WriteLine($"ClientID: {_socketHandler._getID(_socket)}");
            buf = null;

            try {

                while (_socket.State == WebSocketState.Open)
                {
                    var rcvBuffer = new ArraySegment<byte>(new byte[8192]);
                    var totalBytes = new List<byte>();
                    WebSocketReceiveResult? data = null;

                    do {
                        data = await _socket.ReceiveAsync(rcvBuffer, CancellationToken.None);
                        for (int i=0; i < data.Count; i++)
                        {
                            totalBytes.Add(rcvBuffer.Array[i]);
                        }
                    } while(!data.EndOfMessage);
                    
                    var recvData = Encoding.UTF8.GetString(totalBytes.ToArray(), 0, totalBytes.Count).TrimEnd('\0');

                    
                    if(recvData.StartsWith("SET ")){

                        var reply = _socketHandler._setID(_socket, recvData.Split(" ")[1]);
                        Console.WriteLine($"Set ID: {reply}");
                        Console.WriteLine("<==========End of Reply==========>");
                    }else {
                        Response?  DeRep;

                        DeRep = Newtonsoft.Json.JsonConvert.DeserializeObject<Response>(recvData);
                        if(DeRep != null){
                            Console.WriteLine($"Response Headers: {DeRep.statusCode}\r\n");
                            if(String.IsNullOrEmpty(DeRep.headers) == false)
                                Console.WriteLine($"{DeRep.headers}");

                            HttpListenerContext? _resContext = null;
                            if(DeRep.cliID != null)
                                _httpReqLists.TryGetValue(DeRep.cliID, out _resContext);
                            if ((int?)DeRep.statusCode == 404)
                            {
                                if(_resContext != null){
                                    _resContext.Response.StatusCode = (int)DeRep.statusCode;
                                    _resContext.Response.OutputStream.Flush();
                                    await _resContext.Response.OutputStream.DisposeAsync();
                                }
                                
                            }else if((int?)DeRep.statusCode == 307)
                            {
                                if(_resContext != null){
                                    _resContext.Response.StatusCode = (int)DeRep.statusCode;

                                    _resContext.Response.RedirectLocation = String.Concat(baseUrl,DeRep.request.Split("/")[1],"/url=",DeRep.headers);
                                    _resContext.Response.OutputStream.Flush();
                                    await _resContext.Response.OutputStream.DisposeAsync();
                                }
                            }
                            else {
                                Console.WriteLine($"Content-Type: {DeRep.contentType}");
                                if(_resContext != null){
                                    _resContext.Response.ContentType = DeRep.contentType;
                                    _resContext.Response.StatusCode = (int)DeRep.statusCode;
                                    // if ((int)DeRep.statusCode != 404)
                                    // {
                                        byte[]? respBytes = null;
                                        if(DeRep.response != null){
                                            respBytes = Convert.FromBase64String(DeRep.response);
                                            
                                            
                                            if(DeRep.contentType != null && DeRep.contentType.Contains("text/html"))
                                            {
                                                var tempData = encoding.GetString(respBytes);
                                                // if(tempData.Contains("=\"/") || tempData.Contains("=\"http")){
                                                if(DeRep.request != null){
                                                    // extract the domain from reuest
                                                    var reqBaseUrl = DeRep.request.Split("=")[1];
                                                    Uri reqUrl = new Uri(reqBaseUrl);
                                                    reqBaseUrl = reqUrl.GetLeftPart(UriPartial.Authority);


                                                    // Console.WriteLine(reqBaseUrl);

                                                    tempData = tempData.Replace("=\"/",String.Concat("=\"",reqBaseUrl,"/")).Replace("=\"http",String.Concat("=\"",baseUrl,DeRep.request.Split("/")[1],"/url=http"));
                                                    tempData = tempData.Replace("=\"//",String.Concat("=\"",baseUrl,DeRep.request.Split("/")[1],"/url=https://"));
                                                    tempData = tempData.Replace("=\'//",String.Concat("=\'",baseUrl,DeRep.request.Split("/")[1],"/url=https://"));
                                                    tempData = tempData.Replace(" \"//",String.Concat("=\"",baseUrl,DeRep.request.Split("/")[1],"/url=https://"));

                                                    tempData = tempData.Replace("href=\"/fonts",String.Concat("href=\"",baseUrl,DeRep.request.Split("/")[1],"/url=https://fonts"));
                                                    tempData = tempData.Replace("href=\"//fonts",String.Concat("href=\"",baseUrl,DeRep.request.Split("/")[1],"/url=https://fonts"));
                                                    tempData = tempData.Replace("= \"http",String.Concat("=\"",baseUrl,DeRep.request.Split("/")[1],"/url=http")).Replace("= \'http",String.Concat("=\'",baseUrl,DeRep.request.Split("/")[1],"/url=http")).Replace("=\'http",String.Concat("=\'",baseUrl,DeRep.request.Split("/")[1],"/url=http"));
                                                    
                                                }
                                                // Console.WriteLine(tempData);
                                                respBytes = encoding.GetBytes(tempData);
                                            }
                                            
                                        }else {
                                            Console.WriteLine("Response is null i.e No Content");
                                        }
                                            
                                        // Console.WriteLine(_resContext.Response..ToString());
                                        if(respBytes != null)
                                        await _resContext.Response.OutputStream.WriteAsync(respBytes, 0, respBytes.Length);
                                        _resContext.Response.OutputStream.Flush();
                                        await _resContext.Response.OutputStream.DisposeAsync();
                                    // }
                                    

                                    
                                }
                                
                            }
                            _resContext.Response.OutputStream.Close();
                            
                        }
                        
                    }

                    if(data.MessageType == WebSocketMessageType.Close)
                     {   
                        Console.WriteLine("Error occured");
                        await _socket.CloseAsync(WebSocketCloseStatus.NormalClosure, "", CancellationToken.None);
                   } 
                }
            } catch (Exception) {
                // Console.WriteLine($"Error: {ex}");

                await _socketHandler.OnDisconnected(_socket);
                Console.WriteLine("A client got disconnected...");
            } finally {
                if(_socket != null)
                    _socket.Dispose();
            }
        }

        public static string Base64Dec(string encoded)
        {
            var byteStr = Convert.FromBase64String(encoded);
            return encoding.GetString(byteStr);
        }

        public static string ConstructQueryString(NameValueCollection parameters)
        {
            List<string> items = new List<string>();

            foreach (string name in parameters)
                items.Add(string.Concat(name, "=", HttpUtility.UrlEncode(parameters[name])));

            return string.Join("&", items.ToArray());
        }
    }
}
