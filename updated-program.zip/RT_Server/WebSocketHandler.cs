using System;
using System.Linq;
using System.Net.WebSockets;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Text;

namespace RT_Server {

  public class WebSocketHandler {
    protected ConnectionManager _webSocketmanager = new ConnectionManager();

        // public WebSocketHandler(ConnectionManager webSocketConnectionManager)
        // {
        //   _webSocketmanager = webSocketConnectionManager;
        // }

        public void OnConnected(WebSocket socket, string id)
        {
            _webSocketmanager.AddSocket(socket, id);
        }

        public async Task OnDisconnected(WebSocket socket)
    {
      await _webSocketmanager.RemoveSocket(_webSocketmanager.GetId(socket));
    }

    public async Task SendMessageAsync(WebSocket socket, string message)
    {
      if(socket.State != WebSocketState.Open)
        return;

      await socket.SendAsync(buffer: new ArraySegment<byte>(array: Encoding.ASCII.GetBytes(message), offset: 0,
      count: message.Length), messageType: WebSocketMessageType.Text,
      endOfMessage: true,
      cancellationToken: CancellationToken.None);
    }

    public async Task SendMessageAsync(WebSocket socket,byte[] message, WebSocketReceiveResult result)
    {
      if(socket.State != WebSocketState.Open)
        return;

      await socket.SendAsync(buffer: new ArraySegment<byte>(array: message, offset: 0,
      count: result.Count), messageType: WebSocketMessageType.Binary,
      endOfMessage: result.EndOfMessage,
      cancellationToken: CancellationToken.None);
    }

    public async Task SendMessageAsync(string socketId, string message)
    {
      await SendMessageAsync(_webSocketmanager.GetSocketById(socketId), message);
    }

    public async Task SendMessageToAllAsync(string message)
    {
      foreach (var pair in _webSocketmanager.GetAll())
      {
        if(pair.Value.State == WebSocketState.Open)
          await SendMessageAsync(pair.Value, message);
      }
    }

    public string _getID(WebSocket _socket)
    {
      return _webSocketmanager.GetId(_socket);
    }

    public string _setID(WebSocket _socket, string newID)
    {
      return _webSocketmanager.SetSocketId(_socket, newID);
    }

    public WebSocket _getSocket(string id)
    {
      return _webSocketmanager.GetSocketById(id);
    }

    public string CreateConnectionId()
    {
        return Guid.NewGuid().ToString();
    }

    // public abstract Task ReceiveAsync(WebSocket socket, WebSocketReceiveResult result, byte[] buffer);

  }

}
