﻿using System.Collections.Generic;
using System.Collections.Concurrent;
using System;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Net.WebSockets;
using System.Threading;
using System.Threading.Tasks;
using System.Text.RegularExpressions;
using Newtonsoft.Json;
using System.Web;
using System.Collections.Specialized;

namespace Client {

    public class Program {

        private static UTF8Encoding encoding = new UTF8Encoding();
        

        static void Main(string[] args)
        {
            var config = GetConfigData();
            var host = config.FirstOrDefault(p => p.Key == "host").Value;
            var port = config.FirstOrDefault(p => p.Key == "port").Value;
            var id = config.FirstOrDefault(p => p.Key == "clientID").Value;

            Connect($"ws://{host}:{port}/", id).Wait();
            Console.WriteLine("Press any key to exit...");
            Console.ReadKey();
        }

        public static async Task Connect(string url, string id)
        {
            // Thread.Sleep(1000);

            ClientWebSocket? client = null;
            try {
                client = new ClientWebSocket();
                await client.ConnectAsync(new Uri(url), CancellationToken.None);

                byte[] buffer = encoding.GetBytes(id);
                await client.SendAsync(new ArraySegment<byte>(buffer), WebSocketMessageType.Binary, false, CancellationToken.None);

                // await Task.WhenAll(Receive(client), Send(client));
                await Receive(client);
            } catch (Exception ex){
                Console.WriteLine($"Exception: {ex.HResult}");
            }finally
            {
                if(client != null)
                    client.Dispose();

                Console.WriteLine();
                Console.WriteLine("websocket closed.");
            }
        }

        private static async Task Send(ClientWebSocket socket)
        {
            while(socket.State == WebSocketState.Open)
            {
                Console.WriteLine("Send Command: ");
                string? stringToSend = Console.ReadLine();
                byte[]? buffer = null;
                if(stringToSend != null)
                buffer = encoding.GetBytes(stringToSend);

                if(buffer != null)
                await socket.SendAsync(new ArraySegment<byte>(buffer), WebSocketMessageType.Binary, true, CancellationToken.None);
                Console.WriteLine($"Sent: {stringToSend}");
                

                await Task.Delay(1000);
            }
        }

        private static async Task Receive(ClientWebSocket socket)
        {
            
            while(socket.State == WebSocketState.Open)
            {
                byte[] buffer = new byte[4096*4];
                
                var result = await socket.ReceiveAsync(new ArraySegment<byte>(buffer), CancellationToken.None);
                
                // Console.WriteLine(result.MessageType);

                if(result.MessageType == WebSocketMessageType.Close)
                {
                    Console.WriteLine("Socket Closed");
                    await socket.CloseAsync(WebSocketCloseStatus.NormalClosure, string.Empty, CancellationToken.None);
                } else {
                    // check the buffer object type
                    var response = Encoding.UTF8.GetString(buffer).Trim();
                
                    // DeserializeObject response
                    var DeRep =  JsonConvert.DeserializeObject<Response>(response);
                    string? webHeaderCollection = null;
                    NameValueCollection? parsedHeaders = null;
                    if(DeRep != null){
                        webHeaderCollection = DeRep.headers;
                        if(DeRep.headers != null)
                            parsedHeaders = parseQuery(DeRep.headers);

                        if(webHeaderCollection != null)
                        if (DeRep.method != "" || webHeaderCollection.Contains("Connection: "))
                        {
                            // parse the method and url from the  httpRequest response string
                            string? url = null;
                            var method = DeRep.method;
                            if(DeRep.request != null)
                            url = DeRep.request.Substring(DeRep.request.IndexOf("=")+1);
                            if(url != null && url.Contains("url=")){
                                url = url.Substring(url.IndexOf("=") + 1);
                            }
                            var connID = DeRep.cliID; 
                            
                            Console.WriteLine("Request: Header\r\n");
                        
                            Console.WriteLine($"{method} {url} HTTP/{DeRep.protocol}\r\n");
                        
                            if(parsedHeaders != null)
                            foreach(string key in parsedHeaders)
                                Console.WriteLine($"{key}: {parsedHeaders[key]}");

                            HttpClient _httpCl = new HttpClient(
                                new HttpClientHandler
                                {
                                    AllowAutoRedirect = true
                                }
                            );
                            var requestMessage = new HttpRequestMessage();
                            if (method == "GET")
                            {
                                requestMessage.Method = HttpMethod.Get;
                            }else if (method == "HEAD")
                            {
                                requestMessage.Method = HttpMethod.Head;
                            } else if (method == "POST")
                            {
                                requestMessage.Method = HttpMethod.Post;
                            }
                            else if (method == "DELETE")
                            {
                                requestMessage.Method = HttpMethod.Delete;
                            } else if (method == "PUT")
                            {
                                requestMessage.Method = HttpMethod.Put;
                            }

                            try
                            {
                                if(string.IsNullOrEmpty(DeRep.response) == false)
                                    requestMessage.Content = new StringContent(DeRep.response, Encoding.UTF8, DeRep.contentType);

                                if(parsedHeaders != null)
                                {
                                    requestMessage.Headers.Accept.TryParseAdd(parsedHeaders["Accept"]);
                                    requestMessage.Headers.AcceptLanguage.TryParseAdd(parsedHeaders["Accept-Language"]);
                                    requestMessage.Headers.UserAgent.ParseAdd(parsedHeaders["User-Agent"]);
                                    requestMessage.Headers.Connection.TryParseAdd(parsedHeaders["Connection"]);
                                    requestMessage.Headers.Add("Cookie", parsedHeaders["Cookie"]);
                                    requestMessage.Headers.Upgrade.ParseAdd(parsedHeaders["Upgrade-Insecure-Requests"]);
                                    
                                }
                                
                            }
                            catch (Exception)
                            {
                                throw;
                            }
                            if(url != null)
                                requestMessage.RequestUri = new Uri(url, UriKind.RelativeOrAbsolute);

                            try
                            {
                                string? resultWeb = ""; 
                                string? tempContType;
                                byte[]? ResBytes;
                                string? jsonReq;
                                Response obj;
                                HttpResponseMessage responseMessage;

                                responseMessage = await _httpCl.SendAsync(requestMessage, HttpCompletionOption.ResponseContentRead, CancellationToken.None);   
                                
                                // responseMessage.Headers.Remove("transfer-encoding");
                                switch ((int)responseMessage.StatusCode)
                                {
                                    case 301:
                                    case 302:
                                    case 303:
                                    case 307:
                                    case 404:
                                        int statusCode = (int)responseMessage.StatusCode;
                                        var header = "";
                                        Console.WriteLine($"Error {(int)responseMessage.StatusCode} occured");
                                        // if (statusCode != 404)
                                        // {
                                        //     Console.WriteLine(responseMessage.Headers.Location);
                                        // }
                                        if(responseMessage.Content.Headers.ContentType == null){
                                            Console.WriteLine("Response Message Header is null");
                                        }
                                        if(responseMessage.Content.Headers.ContentType == null){
                                            Console.WriteLine("Response Message Content Type is null");
                                        }
                                        if(responseMessage.Content == null)
                                            Console.WriteLine("Response Message Content is null");
                                        // }else {
                                        //     var resp = await responseMessage.Content.ReadAsStringAsync(CancellationToken.None);
                                        //     Console.WriteLine(resp);
                                        // }
                                        if(statusCode == 307)
                                            header = responseMessage.Headers.Location.OriginalString;
                                        Console.WriteLine(header);                                        
                                        obj = new Response
                                        {
                                            cliID = DeRep.cliID,
                                            method = DeRep.method,
                                            response = "",
                                            headers = header,
                                            contentType = "",
                                            request = DeRep.request,
                                            statusCode = statusCode
                                        };

                                        jsonReq = JsonConvert.SerializeObject(obj);
                                        Console.WriteLine(jsonReq);
                                        ResBytes = Encoding.UTF8.GetBytes(jsonReq);
                                        Console.WriteLine($"\n\nResponse Headers: {responseMessage.StatusCode}");
                                        // Console.WriteLine($"Content-Type: {responseMessage.Content.Headers.ContentType?.MediaType};{responseMessage.Content.Headers.ContentType?.CharSet}");
                                            
                                        await socket.SendAsync(new ArraySegment<byte>(ResBytes),WebSocketMessageType.Binary, true, CancellationToken.None);

                                        break;
                                    default:
                                        Console.WriteLine($"Response Status Code: {(int)responseMessage.StatusCode}");
                                        if(string.IsNullOrEmpty(responseMessage.Content.Headers.ContentType?.CharSet)){
                                            tempContType = responseMessage.Content.Headers.ContentType?.MediaType;
                                            
                                        }else {
                                            tempContType = $"{responseMessage.Content.Headers.ContentType?.MediaType};charset={responseMessage.Content.Headers.ContentType?.CharSet}";
                                            
                                        }
                                        
                                        // Console.WriteLine(responseMessage.Content.ReadAsStringAsync().Result);
                                        // if(responseMessage.Content.Headers.ContentType?.MediaType != null)
                                        if ((bool)responseMessage.Content.Headers.ContentType?.MediaType.Contains("image"))
                                        {
                                            var bytContent = await responseMessage.Content.ReadAsByteArrayAsync();
                                            resultWeb = Convert.ToBase64String(bytContent);
                                        }else
                                        {
                                            // resultWeb  = responseMessage.Content.ReadAsStringAsync().Result;
                                            var bytContent  = await responseMessage.Content.ReadAsByteArrayAsync();
                                            resultWeb = Convert.ToBase64String(bytContent);
                                        }
            
                                        obj = new Response
                                        {
                                            cliID = DeRep.cliID,
                                            method = DeRep.method,
                                            response = resultWeb,
                                            headers = responseMessage.Headers.ToString(),
                                            contentType = tempContType,
                                            request = DeRep.request,
                                            statusCode = (int)responseMessage.StatusCode
                                        };
                                        
                                        jsonReq = JsonConvert.SerializeObject(obj);
                                        
                                        ResBytes = Encoding.UTF8.GetBytes(jsonReq);
                                        Console.WriteLine($"\n\nResponse Headers: {responseMessage.StatusCode}\r\n{responseMessage.Headers.ToString()}");
                                        Console.WriteLine($"Content-Type: {responseMessage.Content.Headers.ContentType?.MediaType};{responseMessage.Content.Headers.ContentType?.CharSet}");
                                            
                                        await socket.SendAsync(new ArraySegment<byte>(ResBytes),WebSocketMessageType.Binary, true, CancellationToken.None);

                                        break;
                                }
                                
                                // var linkParser = new Regex(@"\b(?:https?://|www\.)\S+\b", RegexOptions.Compiled | RegexOptions.IgnoreCase);
                                // foreach (Match link in linkParser.Matches(resultWeb))
                                // {
                                //     Console.WriteLine(link.Value);
                                // }
                                // Serialize Response Object
                                
    
                            }
                            catch (Exception ex)
                            {
                                Console.WriteLine(ex.Message);
                                Console.WriteLine("Could not fetch website link...");
                            }
                            
                        }else {
                            Console.WriteLine($"Receive: {response}");
                        }
                    }
                    
                    
                }
            }
        }

        private static ConcurrentDictionary<string, string> GetConfigData()
        {
            ConcurrentDictionary<string, string> storage = new ConcurrentDictionary<string, string>();

            var handle = File.ReadAllText(@"config.ini");
            string[] settings = handle.TrimEnd().Split(Environment.NewLine);
            
            foreach(var line in settings)
            {
                if(line != Environment.NewLine || line != string.Empty){
                    var getKeyValue = line.Split('=');
                    storage.TryAdd(getKeyValue[0], getKeyValue[1]);
                }
            }
            return storage;
        }
        private static ConcurrentDictionary<string, string> GetHeaders(string headers)
        {
            ConcurrentDictionary<string, string> storage = new ConcurrentDictionary<string, string>();

            string[] settings = headers.TrimEnd('\r').TrimEnd('\n').Split("\n");

            for (int i = 2; i < settings.Length - 2; i++)
            {                
                var getKeyValue = settings[i].Trim().Split(':');
                if (settings[i].Contains("User-Agent:") || settings[i].Contains("Host:"))
                {
                    var agent_value = settings[i].Trim().Substring(getKeyValue[0].Length + 1);
                    storage.TryAdd(getKeyValue[0], agent_value);   
                }else {
                    storage.TryAdd(getKeyValue[0], getKeyValue[1]);
                }
            }
            return storage;
        }

        public static string Base64Enc(string str)
        {
            var byteStr = encoding.GetBytes(str);
            return Convert.ToBase64String(byteStr);
        }
        
        public static string ConstructQueryString(NameValueCollection parameters)
        {
            List<string> items = new List<string>();

            foreach (string name in parameters)
                items.Add(string.Concat(name, "=", HttpUtility.UrlEncode(parameters[name])));

            return string.Join("&", items.ToArray());
        }
         
        public static string DecodeQueryString(NameValueCollection parameters)
        {
            List<string> items = new List<string>();

            foreach (string name in parameters)
                items.Add(string.Concat(name, ":", parameters[name]));

            return string.Join("\n", items.ToArray());
        }

        public static NameValueCollection? parseQuery(string queryString)
        {
            NameValueCollection headers = new NameValueCollection();
            string[] tempCollect = queryString.Split('&');
            foreach (var header in tempCollect)
            {
                var headerKey = header.Split('=')[0];
                var headerValue = HttpUtility.UrlDecode(header.Split('=')[1]);
                headers.Set(headerKey, headerValue);
            }
            return headers;
        }
    }
}
